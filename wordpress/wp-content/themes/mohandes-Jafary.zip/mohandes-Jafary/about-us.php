<?php
	get_tamplate_part('header');
?>

    <ul class="site-nav">
      <li><a href="../../../../Mohandes Jafary - wp/site/home.html">خانه</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/about-us.html" class="act">درباره ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/articles.html">مقالات</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/contact-us.html">تماس با ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/sitemap.html">نقشه سایت</a></li>
    </ul>
    <div class="logo"><a href="../../../../Mohandes Jafary - wp/site/home.html"><!--<img src="images/logo.gif" alt="" />-->site rasmiye mohandes mehdi jafary </a></div>
  </div>
  <!-- content -->
  <div id="content">
    <div class="indent1">
      <div class="indent">
        <h2>About Your Website</h2>
        <p>This is an "About Us" page. You are supposed to fill it with some information on your website or your company. People usually write about history of the company or about the website - why it was created, when, etc. If there are more than one person who supports the website you may consider writning about each memeber of your team.</p>
      </div>
      <h2>About Your Team</h2>
      <ul class="list1">
        <li><img src="../../../../Mohandes Jafary - wp/site/images/2page-img1.jpg" alt="" /><a href="#">Team Member One</a><br />
          He is supposed to be the most important member of your team. Ususally this is the person who started the website. Maybe it is worth to write why he made such a desicion, what inspired him and what are his plans for the future.</li>
        <li><img src="../../../../Mohandes Jafary - wp/site/images/2page-img2.jpg" alt="" /><a href="#">Another Team Member</a><br />
          We are completly lost on what he's responsible for but we hope that you know it ;) We also hope that you will tell it to the rest of the world including us by placing some real text here. If this person has his own website this is a good place to link to it...</li>
        <li><img src="../../../../Mohandes Jafary - wp/site/images/2page-img3.jpg" alt="" /><a href="#">The Last One Team Member</a><br />
          We are completly lost on what he's responsible for but we hope that you know it ;) We also hope that you will tell it to the rest of the world including us by placing some real text here. If this person has his own website this is a good place to link to it...</li>
      </ul>
    </div>
  </div>
  <!-- footer -->
   <div id="footer">
    <div class="indent">
      <div class="fright">Copyright - ??????????(site name)</div>
      <span class="fleft">:Designed by</span>
      <div class="fleft"><a href="http://www.zahedy.ir"><img alt="website templates " src="../../../../Mohandes Jafary - wp/site/images/templates-logo.png" title="zahedy.ir - website templates provider" /></a></div>
    </div>
  </div>
  
</div>
<!--<script type="text/javascript"> Cufon.now(); </script>-->
</body>
</html>
