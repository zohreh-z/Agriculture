<?php
	get_tamplate_part('header');
?>

    <ul class="site-nav">
      <li><a href="../../../../Mohandes Jafary - wp/site/home.html">خانه</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/about-us.html">درباره ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/articles.html" class="act">مقالات</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/contact-us.html">تماس با ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/sitemap.html">نقشه سایت</a></li>
    </ul>
    <div class="logo"><a href="../../../../Mohandes Jafary - wp/site/home.html"><!--<img src="images/logo.gif" alt="" />-->site rasmiye mohandes mehdi jafary </a></div>
  </div>
  <!-- content -->
  <div id="content">
    <div class="indent1">
      <h2>Article 1</h2>
      <div class="img-box1"><img src="../../../../Mohandes Jafary - wp/site/images/4page-img.jpg" alt="" />
        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>
        <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>
        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
        <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
      </div>
    </div>
  </div>
  <!-- footer -->
 <div id="footer">
    <div class="indent">
      <div class="fright">Copyright - ??????????(site name)</div>
      <span class="fleft">:Designed by</span>
      <div class="fleft"><a href="http://www.zahedy.ir"><img alt="website templates " src="../../../../Mohandes Jafary - wp/site/images/templates-logo.png" title="zahedy.ir - website templates provider" /></a></div>
    </div>
  </div>
  
</div>
<!--<script type="text/javascript"> Cufon.now(); </script>-->
</body>
</html>
