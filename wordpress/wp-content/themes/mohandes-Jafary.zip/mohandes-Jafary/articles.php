<?php 
	get_template_part('header');
?>
    <ul class="site-nav">
      <li><a href="../../../../Mohandes Jafary - wp/site/home.html">خانه</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/about-us.html">درباره ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/articles.html" class="act">مقالات</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/contact-us.html">تماس با ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/sitemap.html">نقشه سایت</a></li>
    </ul>
    <div class="logo"><a href="../../../../Mohandes Jafary - wp/site/home.html"><!--<img src="images/logo.gif" alt="" />-->site rasmiye mohandes mehdi jafary </a></div>
  </div>
  <!-- content -->
  <div id="content">
    <div class="indent1">
      <h2>Articles</h2>
      <ul class="list1">
        <li><img src="../../../../Mohandes Jafary - wp/site/images/3page-img1.jpg" alt="" />
          <div class="zoom"><a href="../../../../Mohandes Jafary - wp/site/article.html">Article 1</a><br />
            Article 1 description is to be here. Since we have no idea what your article is about we just put standart "Lorem ipsum" text here. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...Lorem Ipsum has been the industry's standard dummy text ever since the 1500s..</div>
        </li>
        <li><img src="../../../../Mohandes Jafary - wp/site/images/3page-img2.jpg" alt="" />
          <div class="zoom"><a href="../../../../Mohandes Jafary - wp/site/article.html">Article 2</a><br />
            Article 2 description is to be here. Since we have no idea what your article is about we just put standart "Lorem ipsum" text here. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</div>
        </li>
        <li><img src="../../../../Mohandes Jafary - wp/site/images/3page-img3.jpg" alt="" />
          <div class="zoom"><a href="../../../../Mohandes Jafary - wp/site/article.html">Article 3</a><br />
            Article 3 description is to be here. Since we have no idea what your article is about we just put standart "Lorem ipsum" text here. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...Lorem Ipsum has been the industry's standard dummy text ever since the 1500s..</div>
        </li>
        <li><img src="../../../../Mohandes Jafary - wp/site/images/3page-img4.jpg" alt="" />
          <div class="zoom"><a href="../../../../Mohandes Jafary - wp/site/article.html">Article 4</a><br />
            Article 4 description is to be here. Since we have no idea what your article is about we just put standart "Lorem ipsum" text here. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</div>
        </li>
      </ul>
    </div>
  </div>
  <!-- footer -->
   <div id="footer">
    <div class="indent">
      <div class="fright">Copyright - ??????????(site name)</div>
      <span class="fleft">:Designed by</span>
      <div class="fleft"><a href="http://www.zahedy.ir"><img alt="website templates " src="../../../../Mohandes Jafary - wp/site/images/templates-logo.png" title="zahedy.ir - website templates provider" /></a></div>
    </div>
  </div>
  
</div>
<!--<script type="text/javascript"> Cufon.now(); </script>-->
</body>
</html>
