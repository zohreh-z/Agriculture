<?php
	get_tamplate_part('header');
?>
    <ul class="site-nav">
      <li><a href="../../../../Mohandes Jafary - wp/site/home.html">خانه</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/about-us.html">درباره ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/articles.html">مقالات</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/contact-us.html" class="act">تماس با ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/sitemap.html">نقشه سایت</a></li>
    </ul>
    <div class="logo"><a href="../../../../Mohandes Jafary - wp/site/home.html"><!--<img src="images/logo.gif" alt="" />-->site rasmiye mohandes mehdi jafary </a></div>
  </div>
  <!-- content -->
  <div id="content">
    <div class="indent1">
      <h2>Contact Us</h2>
      <p>You are supposed to place some contact infromation on this page. You may place a map here with some instructions on how to get to your office or just a contact form. Note that the contact form below is not working.</p>
      <form id="contacts-form" action="">
        <fieldset>
        <div class="field">
          <label>Your Name:</label>
          <input type="text" value=""/>
        </div>
        <div class="field">
          <label>Your E-mail:</label>
          <input type="text" value=""/>
        </div>
        <div class="field">
          <label>Your Website:</label>
          <input type="text" value=""/>
        </div>
        <div class="field">
          <label>Your Message:</label>
          <textarea cols="1" rows="1"></textarea>
        </div>
        <div class="alignright"><a href="#" onclick="document.getElementById('contacts-form').submit()"><strong>Send Your Message!</strong></a></div>
        </fieldset>
      </form>
    </div>
  </div>
  <!-- footer -->
 <div id="footer">
    <div class="indent">
      <div class="fright">Copyright - ??????????(site name)</div>
      <span class="fleft">:Designed by</span>
      <div class="fleft"><a href="http://www.zahedy.ir"><img alt="website templates " src="../../../../Mohandes Jafary - wp/site/images/templates-logo.png" title="zahedy.ir - website templates provider" /></a></div>
    </div>
  </div>
  
</div>
<!--<script type="text/javascript"> Cufon.now(); </script>-->
</body>
</html>
