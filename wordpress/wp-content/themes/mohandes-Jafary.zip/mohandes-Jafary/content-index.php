<!-- start content -->
  <div id="content">
    <div class="indent1">
      <div class="indent">
        <h2>Welcome to Animal Planet!</h2>
        <h3>Animal Planet is a free websites template created by Templates.com team. This website template is optimized for 1024X768 screen resolution. It is also XHTML &amp; CSS valid.</h3>
        <p>The website template goes with two packages – with PSD source files and without them. PSD source files are available for free for the registered members of Templates.com. The basic package (without PSD is available for anyone without registration).</p>
      </div>
      <h2>Recent Articles</h2>
      <ul class="list">
        <li><a href="#">Animal Planet</a><br />
          From our site you will learn interesting facts about animal planet and its inhabitants. Your journey starts here!</li>
        <li><a href="#">Animal Planet Template</a><br />
          Free 1028X768 Optimized Website Template from Templates.com! We really hope that you like this template and will use for your websites.</li>
        <li><a href="#">Travel to the Animal Planet</a><br />
          The captivating stories about the journey to the animal planet you can read in this sample article.</li>
      </ul>
    </div>
  </div>
<!-- end content -->