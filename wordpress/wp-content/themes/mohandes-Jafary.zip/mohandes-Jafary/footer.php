 <!-- footer -->
  <div id="footer">
    <div class="indent">
      <div class="fright">Copyright - ??????????(site name)</div>
      <span class="fleft">:Designed by</span>
      <div class="fleft"><a href="http://www.zahedy.ir"><img alt="website templates " src="../../../../Mohandes Jafary - wp/site/images/templates-logo.png" title="zahedy.ir - website templates provider" /></a></div>
    </div>
  </div>
  
</div>
</body>
</html>
