<?php
	register_nav_menu('mainmenu', "Main Manu");
?>