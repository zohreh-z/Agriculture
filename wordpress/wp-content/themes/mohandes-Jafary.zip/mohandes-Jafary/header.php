<!DOCTYPE HTML>
<html>
<head>

  <title>Home </title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link href="<?php bloginfo('template_url'); ?>\style.css" rel="stylesheet" type="text/css" />
  <!--[if lt IE 7]>
     <link href="<?php bloginfo('template_url'); ?>\style_ie.css" rel="stylesheet" type="text/css" />
  <![endif]-->

</head>
<body>
<div id="main">
  <!-- header -->
  <div id="header">