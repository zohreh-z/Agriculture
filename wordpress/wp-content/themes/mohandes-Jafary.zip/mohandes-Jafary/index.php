<?php
	get_template_part('header');
	get_template_part('nav');
	get_template_part('content','index');
	get_template_part('footer');
?>
    
  
 