	<ul class="site-nav">
	   <!-- <li><a href="./index.php" class="act">خانه</a></li>
	    <li><a href="./about-us.php"> درباره ما</a></li>
	    <li><a href="./articles.php">مقالات</a></li>
	    <li><a href="./contact-us.php"> تماس با ما</a></li>
		<li><a href="./sitemap.php"> نقشه سایت</a></li>-->
        <?php
			wp_nav_menu(array(
				'theme_location'  => 'mainmenu',
				'container'       => false, 
				'container_class' => '', 
				'menu_class'      => '', 
				'before'          => '',
				'after'           => '',
				'link_before'     => '',
				'link_after'      => '',
				'items_wrap'      => '<ul class="%2$s">%3$s</ul>')
			);
		?>
	</ul>
	<div class="logo"><a href="./index.php"><!--<img src="images/logo.gif" alt="" />-->site rasmiye mohandes mehdi jafary </a></div>
</div>