<?php
	get_tamplate_part('header');
?>

    <ul class="site-nav">
      <li><a href="../../../../Mohandes Jafary - wp/site/home.html">خانه</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/about-us.html">درباره ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/articles.html">مقالات</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/contact-us.html">تماس با ما</a></li>
      <li><a href="../../../../Mohandes Jafary - wp/site/sitemap.html" class="act">نقشه سایت</a></li>
    </ul>
    <div class="logo"><a href="../../../../Mohandes Jafary - wp/site/home.html"><!--<img src="images/logo.gif" alt="" />-->site rasmiye mohandes mehdi jafary </a></div>
  </div>
  <!-- content -->
  <div id="content">
    <div class="indent1">
      <h2>Site Map</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ornare lobortis elit vel venenatis. Vivamus magna arcu, placerat in elementum quis, luctus et magna. Aenean pharetra ultrices nibh, eu tempor enim commodo eu. Mauris faucibus eros nec ligula molestie accumsan. Fusce tempus porttitor porta. In pellentesque suscipit ipsum nec tincidunt.</p>
      <ul class="list2">
        <li><a href="../../../../Mohandes Jafary - wp/site/home.html">Home</a></li>
        <li><a href="../../../../Mohandes Jafary - wp/site/about-us.html">About Us</a></li>
        <li><a href="../../../../Mohandes Jafary - wp/site/articles.html">Articles</a>
          <ul>
            <li><a href="../../../../Mohandes Jafary - wp/site/article.html">Article 1</a></li>
            <li><a href="../../../../Mohandes Jafary - wp/site/article.html">Article 2</a></li>
            <li><a href="../../../../Mohandes Jafary - wp/site/article.html">Article 3</a></li>
          </ul>
        </li>
        <li><a href="../../../../Mohandes Jafary - wp/site/contact-us.html">Contact Us</a></li>
      </ul>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ornare lobortis elit vel venenatis. Vivamus magna arcu, placerat in elementum quis, luctus et magna. Aenean pharetra ultrices nibh, eu tempor enim commodo eu.</p>
    </div>
  </div>
   <div id="footer">
    <div class="indent">
      <div class="fright">Copyright - ??????????(site name)</div>
      <span class="fleft">:Designed by</span>
      <div class="fleft"><a href="http://www.zahedy.ir"><img alt="website templates " src="../../../../Mohandes Jafary - wp/site/images/templates-logo.png" title="zahedy.ir - website templates provider" /></a></div>
    </div>
  </div>
  
</div>
 
<!--<script type="text/javascript"> Cufon.now(); </script>-->
</body>
</html>
